# Storyboard – Tilt Maze

Dieses Dokument enthält die Screen-Storyboards für die App «Tilt Maze».

## Screen 1: LoginScreen

```
┌─────────────────────────────────────┐
│                                     │
│                                     │
│           ┌─────────┐               │
│           │  LOGO   │               │
│           │  TILT   │               │
│           │  MAZE   │               │
│           └─────────┘               │
│                                     │
│         Willkommen bei              │
│           Tilt Maze                 │
│                                     │
│                                     │
│    ┌───────────────────────────┐    │
│    │   [G] Mit Google anmelden │    │
│    └───────────────────────────┘    │
│                                     │
│                                     │
│                                     │
│                                     │
└─────────────────────────────────────┘

Funktionen:
- Google Sign-In Button
- Neon-Cyan Farbschema
- Animierter Glow-Effekt
```

## Screen 2: MenuScreen

```
┌─────────────────────────────────────┐
│                         [Settings]  │
│                                     │
│         Willkommen,                 │
│         [Nickname]!                 │
│                                     │
│         ┌─────────────┐             │
│         │ [✏️ Edit]   │             │
│         └─────────────┘             │
│                                     │
│                                     │
│    ┌───────────────────────────┐    │
│    │     🎮 Spiel starten      │    │
│    └───────────────────────────┘    │
│                                     │
│    ┌───────────────────────────┐    │
│    │     🏆 Highscores         │    │
│    └───────────────────────────┘    │
│                                     │
│    ┌───────────────────────────┐    │
│    │     🚪 Logout             │    │
│    └───────────────────────────┘    │
│                                     │
└─────────────────────────────────────┘

Funktionen:
- Begrüssung mit Nickname
- Nickname bearbeiten
- Navigation zu Game/Highscores
- Logout-Funktion
```

## Screen 3: GameScreen

```
┌─────────────────────────────────────┐
│  [←]                    ⏱️ 0.00s   │
│─────────────────────────────────────│
│                                     │
│  ●                                  │
│ (Kugel)                             │
│         ████████████████████        │
│                                     │
│  ████████████████████               │
│                                     │
│         ████████████████████        │
│                                     │
│  ████████████████████               │
│                                     │
│         ████████████████████        │
│                                     │
│  ████████████████████               │
│                                     │
│         ████████████████████        │
│                                     │
│  ████████████████████       ◉       │
│                          (Ziel)     │
│                                     │
│    Neige das Gerät zum Steuern      │
│              [⚙️]                    │
└─────────────────────────────────────┘

Funktionen:
- Kugel (Cyan, oben links)
- Ziel (Grün, unten rechts)
- Zick-Zack Maze-Wände
- Timer in Kopfzeile
- Zurück-Button
- Settings-Button
```

## Screen 4: ResultScreen

```
┌─────────────────────────────────────┐
│                                     │
│                                     │
│            🏆 GESCHAFFT!            │
│                                     │
│                                     │
│         ┌─────────────────┐         │
│         │                 │         │
│         │     12.34s      │         │
│         │                 │         │
│         └─────────────────┘         │
│                                     │
│        ⭐ New Personal Best!        │
│                                     │
│                                     │
│    ┌───────────────────────────┐    │
│    │     🔄 Nochmal spielen    │    │
│    └───────────────────────────┘    │
│                                     │
│    ┌───────────────────────────┐    │
│    │     🏆 Highscores         │    │
│    └───────────────────────────┘    │
│                                     │
│    ┌───────────────────────────┐    │
│    │     🏠 Zurück zum Menü    │    │
│    └───────────────────────────┘    │
│                                     │
└─────────────────────────────────────┘

Funktionen:
- Erreichte Zeit gross anzeigen
- Status: Neue Bestzeit / Keine neue Bestzeit
- Nochmal spielen
- Zu Highscores
- Zurück zum Menü
```

## Screen 5: HighscoresScreen

```
┌─────────────────────────────────────┐
│  [←]         HIGHSCORES             │
│─────────────────────────────────────│
│                                     │
│  ┌─────────────────────────────┐    │
│  │ 🥇 #1  CoolPlayer    5.42s  │    │
│  └─────────────────────────────┘    │
│                                     │
│  ┌─────────────────────────────┐    │
│  │ 🥈 #2  ProGamer      6.15s  │    │
│  └─────────────────────────────┘    │
│                                     │
│  ┌─────────────────────────────┐    │
│  │ 🥉 #3  SpeedKing     7.23s  │    │
│  └─────────────────────────────┘    │
│                                     │
│  ┌─────────────────────────────┐    │
│  │    #4  FastFinger    8.01s  │    │
│  └─────────────────────────────┘    │
│                                     │
│  ┌─────────────────────────────┐    │
│  │    #5  TiltMaster    9.45s  │    │
│  └─────────────────────────────┘    │
│                                     │
│           ... (Top 10)              │
│                                     │
└─────────────────────────────────────┘

Funktionen:
- Top 10 Liste
- Rang, Nickname, Zeit
- Gold/Silber/Bronze für Top 3
- Zurück-Button
```

## Screen 6: SettingsScreen (Modal)

```
┌─────────────────────────────────────┐
│                                     │
│  ┌─────────────────────────────┐    │
│  │       ⚙️ EINSTELLUNGEN      │    │
│  │                             │    │
│  │  Sensitivität               │    │
│  │  ●────────────○ 1.0         │    │
│  │                             │    │
│  │  Deadzone                   │    │
│  │  ●────○───────── 0.05       │    │
│  │                             │    │
│  │  [✓] Vibration aktiviert    │    │
│  │                             │    │
│  │  [ ] X-Achse invertieren    │    │
│  │                             │    │
│  │  ┌───────────────────────┐  │    │
│  │  │      Schliessen       │  │    │
│  │  └───────────────────────┘  │    │
│  └─────────────────────────────┘    │
│                                     │
└─────────────────────────────────────┘

Funktionen:
- Sensitivität-Slider
- Deadzone-Slider
- Vibration Toggle
- Invert-X Toggle
```

## Navigationsfluss

```
                    ┌───────────────┐
                    │  LoginScreen  │
                    └───────┬───────┘
                            │
                    Google Sign-In
                            │
                            ▼
                    ┌───────────────┐
          ┌─────────│  MenuScreen   │─────────┐
          │         └───────┬───────┘         │
          │                 │                 │
     Highscores        Play Game          Logout
          │                 │                 │
          ▼                 ▼                 ▼
   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
   │ Highscores   │  │  GameScreen  │  │ LoginScreen  │
   │   Screen     │  └──────┬───────┘  └──────────────┘
   └──────────────┘         │
                       Ziel erreicht
                            │
                            ▼
                    ┌───────────────┐
                    │ ResultScreen  │
                    └───────────────┘
```

---

*Erstellt im Rahmen des Kompetenznachweises Modul 335*
